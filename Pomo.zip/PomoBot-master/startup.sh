#!/bin/bash

python3.7 bot/main.py
